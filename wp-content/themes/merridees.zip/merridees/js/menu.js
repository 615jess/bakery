jQuery(document).ready(function(){
     jQuery('.mobile-menu').click(function() {
		jQuery('.sidr').toggle("swing");
	 });
})